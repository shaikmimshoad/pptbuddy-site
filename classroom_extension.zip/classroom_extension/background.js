// Downloads Classroom files into  Downloads/PPTBuddy Classroom/PPTBUDDY - <name>
// PPTBuddy watches that folder and adds new files as lessons.
const FOLDER = "PPTBuddy Classroom";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function urlFor(item) {
  const auth = item.authuser ? `&authuser=${encodeURIComponent(item.authuser)}` : "";
  if (item.kind === "slides") {
    return `https://docs.google.com/presentation/d/${item.id}/export/pdf?${auth.slice(1)}`;
  }
  return `https://drive.usercontent.google.com/download?id=${item.id}&export=download&confirm=t${auth}`;
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === "download" && Array.isArray(msg.items)) {
    (async () => {
      let ok = 0;
      for (const item of msg.items) {
        try {
          await chrome.downloads.download({ url: urlFor(item), conflictAction: "uniquify", saveAs: false });
          ok++;
        } catch (e) {
          console.warn("PPTBuddy: download failed", item, e);
        }
        await sleep(400); // be gentle with Google and the browser's multi-download prompt
      }
      sendResponse({ ok, total: msg.items.length });
    })();
    return true; // async response
  }
});

// Keep the file's real name/extension, but put it in the PPTBuddy folder with the PPTBUDDY prefix.
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  if (item.byExtensionId !== chrome.runtime.id) return;
  const base = item.filename.split(/[\\/]/).pop() || "lesson.pdf";
  const name = /^PPTBUDDY/i.test(base) ? base : `PPTBUDDY - ${base}`;
  suggest({ filename: `${FOLDER}/${name}`, conflictAction: "uniquify" });
});

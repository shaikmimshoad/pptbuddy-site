// Adds PPTBuddy download icons to Google Classroom file cards and to each material's title.
(() => {
  const ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11M7 11l5 5 5-5"/><path d="M4 20h16"/></svg>';
  const CHECK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.2 4.2L19 7"/></svg>';
  const authuser = (location.pathname.match(/\/u\/(\d+)\//) || [])[1] || "";

  // Turn a Classroom attachment link into {kind,id}. Works for Drive files and Google Slides.
  function parse(a) {
    let href = a.href || "";
    try {
      const u = new URL(href);
      if (/(^|\.)google\.com$/.test(u.hostname) && u.pathname === "/url") href = u.searchParams.get("q") || u.searchParams.get("url") || href;
    } catch (_) {}
    let m = href.match(/drive\.google\.com\/file\/d\/([\w-]+)/) || href.match(/drive\.google\.com\/(?:open|uc)\?(?:[^#]*&)?id=([\w-]+)/);
    if (m) return { kind: "file", id: m[1], authuser };
    m = href.match(/docs\.google\.com\/presentation\/d\/([\w-]+)/);
    if (m) return { kind: "slides", id: m[1], authuser };
    return null;
  }

  function makeButton(title, extraClass) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "pptbuddy-dl" + (extraClass ? " " + extraClass : "");
    b.title = title;
    b.setAttribute("aria-label", title);
    b.innerHTML = ICON;
    return b;
  }

  function send(items, btn) {
    btn.dataset.state = "busy";
    chrome.runtime.sendMessage({ type: "download", items }, (res) => {
      const ok = res && res.ok > 0 && !chrome.runtime.lastError;
      btn.dataset.state = ok ? "done" : "fail";
      if (ok) btn.innerHTML = CHECK;
      setTimeout(() => { btn.dataset.state = ""; btn.innerHTML = ICON; }, 3000);
    });
  }

  const idsIn = (el) => {
    const seen = new Map();
    el.querySelectorAll("a[href]").forEach((a) => { const p = parse(a); if (p && !seen.has(p.id)) seen.set(p.id, p); });
    return [...seen.values()];
  };

  // The card = the biggest ancestor of the link that still holds only this one file.
  function cardFor(a, id) {
    let card = a;
    for (let i = 0; i < 6 && card.parentElement; i++) {
      const parent = card.parentElement;
      const r = parent.getBoundingClientRect();
      const only = idsIn(parent);
      if (only.length !== 1 || only[0].id !== id || r.height > 220 || r.width > 560) break;
      card = parent;
    }
    return card;
  }

  function decorate() {
    const groups = new Set();
    document.querySelectorAll("a[href]").forEach((a) => {
      const info = parse(a);
      if (!info) return;
      const card = cardFor(a, info.id);
      if (card.dataset.pptbuddy) return;
      card.dataset.pptbuddy = "1";
      if (getComputedStyle(card).position === "static") card.style.position = "relative";
      const btn = makeButton("Add to PPTBuddy");
      btn.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); send([info], btn); }, true);
      card.appendChild(btn);

      // find the material (post) that wraps several files, once
      let g = card, n = 0;
      while (g.parentElement && n++ < 12) {
        g = g.parentElement;
        if (idsIn(g).length >= 2) break;
      }
      if (idsIn(g).length >= 2) {
        const count = idsIn(g).length;
        while (g.parentElement && idsIn(g.parentElement).length === count) g = g.parentElement;
        groups.add(g);
      }
    });

    groups.forEach((g) => {
      if (g.dataset.pptbuddyAll) return;
      const heading = g.querySelector('[role="heading"], h1, h2, h3, h4');
      if (!heading) return;
      g.dataset.pptbuddyAll = "1";
      const btn = makeButton("Add all files in this material to PPTBuddy", "pptbuddy-all");
      btn.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); send(idsIn(g), btn); }, true);
      heading.appendChild(btn);
    });
  }

  let timer = null;
  const schedule = () => { clearTimeout(timer); timer = setTimeout(decorate, 400); };
  new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true });
  decorate();
})();
